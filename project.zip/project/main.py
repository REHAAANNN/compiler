# main.py

from lexer import lexer
from parser_semantic import Parser
from codegen import generate

if __name__ == "__main__":
    user_input = ""

    while True:
        line = input()
        if line.strip() == "ENDINPUT":
            break
        user_input += line + "\n"

    try:
        tokens = lexer(user_input)
        parser = Parser(tokens)
        ast = parser.parse()
        code = generate(ast)

        print(code)

    except Exception as e:
        print("Error:", e)