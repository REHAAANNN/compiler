# codegen.py

def generate(ast, indent=0):
    code = ""

    for node in ast:
        space = "    " * indent

        if node[0] == "ASSIGN":
            code += f"{space}{node[1]} = {node[2]}\n"

        elif node[0] == "PRINT":
            code += f"{space}print({node[1]})\n"

        elif node[0] == "LOOP":
            code += f"{space}for i in range({node[1]}):\n"
            code += generate(node[2], indent + 1)

    return code