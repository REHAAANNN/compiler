# lexer.py
import re

def lexer(text):
    lines = text.strip().split("\n")
    tokens = []

    for line in lines:
        line = line.lower()

        # assignment
        assign = re.findall(r'(\w+)\s*(=|equal to|equals)\s*(\d+)', line)
        if assign:
            for var, _, val in assign:
                tokens.append(("ASSIGN", var, val))

        # create variable
        create = re.findall(r'(create|make).*variable\s+(\w+).*?(\d+)', line)
        if create:
            for _, var, val in create:
                tokens.append(("ASSIGN", var, val))

        # print
        prints = re.findall(r'print\s+(\w+)', line)
        for var in prints:
            tokens.append(("PRINT", var))

        # loop
        loops = re.findall(r'(repeat|loop)\s+(\d+)', line)
        for _, count in loops:
            tokens.append(("LOOP", count))

        if "end" in line:
            tokens.append(("END", None))

    return tokens