# parser_semantic.py

class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.symbol_table = {}

    def current(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def parse(self):
        ast = []
        while self.current():
            ast.append(self.statement())
        return ast

    def statement(self):
        token = self.current()

        if token[0] == "ASSIGN":
            return self.assign()

        elif token[0] == "PRINT":
            return self.print_stmt()

        elif token[0] == "LOOP":
            return self.loop_stmt()

        else:
            raise Exception("Syntax Error")

    def assign(self):
        _, var, val = self.current()
        self.pos += 1

        # semantic: allow update OR create
        self.symbol_table[var] = int(val)

        return ("ASSIGN", var, val)

    def print_stmt(self):
        _, var = self.current()
        self.pos += 1

        if var not in self.symbol_table:
            raise Exception(f"{var} not declared")

        return ("PRINT", var)

    def loop_stmt(self):
        _, count = self.current()
        self.pos += 1

        body = []

        while self.current() and self.current()[0] != "END":
            body.append(self.statement())

        if not self.current():
            raise Exception("Missing END")

        self.pos += 1

        return ("LOOP", count, body)